# Phương pháp vá AOAC

## AOAC: là 1 công nghệ mới từ Intel nhằm mục đích luôn bật, luôn kết nối để laptop có thể duy trì kết nối mạng mọi lúc, nói 1 cách khác thì đó là để máy không bao giờ tắt và luôn luôn có kết nối

## Vấn đề AOAC

### Mất ngủ:  do mâu thuẫn giữa `AOAC` và` S3`, các máy có công nghệ` AOAC` sẽ không có chức năng ngủ 'S3`. Khi máy đi vào giấc ngủ S3 nhưng không thành, nó không thể được đánh thức sau khi ngủ và để hoạt động trở lại chỉ có thể là khởi động lại máy. 

### Vấn đề thời gian chờ:  cấm `S3` ngủ có thể giải quyết vấn đề này, nhưng máy sẽ không còn ngủ nữa và máy sẽ mất đi khoảng 5% -10% mỗi giờ.

## AOAC ngủ, thức dậy

- Khi máy dùng `AOAC` ngủ thì hệ thống và phần cứng sẽ vào trạng thái nhàn rỗi, không hẳn là ngủ.
- Để đánh thức máy dùng `AOAC`, bạn cần dùng phím nguồn + PNP0C0D để thức dậy

## Vá AOAC

### Với phần cứng, bạn hãy nâng cấp lên 1 chiếc SSD xịn cũng như firmware SSD thường xuyên nếu có hoặc là 1 mainboard có support ASPM

### Với phần mềm
- Cấm S3  ngủ bằng SSDT-Disable_S3
- Tăng khả năng SSD vào trạng thái nghỉ bằng SSDT-Deepldle và NVMeFix.kext để bật APST cho SSD
- SSDT-AOAC  Văn bản `Bản vá chung màn hình sáng`
- Vá phím tắt để đánh thức máy:
    + SSDT-FnQ-AOACWake: bản vá chung cho đa số máy, chỉ việc thay đổi phím _LID(_Qxx) phù hợp
    + SSDT-Dell-AOACWake: bản vá chỉ dành cho laptop Dell (Fn + Insert)

## Lưu ý

-Đây mới chỉ là phương pháp tạm thời
-AOAC không liên quan gì đến S3 hay bất kì patch sleep và wake nào
-Không có máy móc AOAC cũng có thể thử phương pháp này.
